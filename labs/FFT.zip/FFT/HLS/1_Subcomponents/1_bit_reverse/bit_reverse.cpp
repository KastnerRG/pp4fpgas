/*
The bit_reverse part of FFT.
INPUT:
	In[]:

OUTPUT:
	Out[]:
 */

#include "bit_reverse.h"
#include <stdio.h>

void bit_reverse(DTYPE X_R[SIZE], DTYPE X_I[SIZE]){

	//Write your code here.

}



