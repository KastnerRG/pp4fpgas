#ifndef __AXI4_LAB_HPP
#define __AXI4_LAB_HPP


void axi4_sqrt(float *,float *,int );
#endif
