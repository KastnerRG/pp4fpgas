0_Initial
	- Software implementation of FFT
1_Subcomponents
	-This folder is essentially for helping you to design different stages of FFT
2_Skeleton_Restructured
	-This folder is for testing your FFT
3_OFDM
	-Your final design: OFDM Receiver
