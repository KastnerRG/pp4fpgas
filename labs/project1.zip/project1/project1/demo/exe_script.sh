./a.out
gnuplot plot_script.p
firefox plot.html
