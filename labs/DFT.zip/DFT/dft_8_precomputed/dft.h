
typedef float DTYPE;
#define SIZE 8 		/* SIZE OF DFT */
void dft(DTYPE XX_R[SIZE], DTYPE XX_I[SIZE]);

